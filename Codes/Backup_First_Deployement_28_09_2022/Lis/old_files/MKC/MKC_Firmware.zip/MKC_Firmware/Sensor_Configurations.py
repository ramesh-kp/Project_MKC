Frequency_Time = "4.0"

Energymeter_Configurations = [
    {'Device_ID': 170, 'Start_Address': 1, 'Register_Counts': 46}]
COD_Configurations = [
    {'Device_ID': 100, 'Start_Address': 9729, 'Register_Counts': 10}]
BOD_Configurations = [
    {'Device_ID': 100, 'Start_Address': 9729, 'Register_Counts': 10}]
Temperature_Configurations = [
    {'Device_ID': 100, 'Start_Address': 9729, 'Register_Counts': 10}]
TSS_Configurations = [
    {'Device_ID': 100, 'Start_Address': 4608, 'Register_Counts': 4}]
Ph_Configurations = [
    {'Device_ID': 110, 'Start_Address': 9729, 'Register_Counts': 5}]
TDS_Configurations = [
    {'Device_ID': 120, 'Start_Address': 9729, 'Register_Counts': 4}]
# Waterlevel_Configurations = [
#     {'Device_ID': 170, 'Start_Address': 1, 'Register_Counts': 46}]
# FlowmeterSensor_Configurations = [
#     {'Device_ID': 170, 'Start_Address': 1, 'Register_Counts': 46}]

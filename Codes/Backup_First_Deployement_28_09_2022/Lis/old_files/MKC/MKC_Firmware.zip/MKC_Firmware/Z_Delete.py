import json
from messages import validation, errorMessage



from Logging_Info import Data_Logs







# sensor = "COD"



# validation = {
#     "MKC1": "Config not found",
#     "MKC2": "EmployeeCode Required"}

# sensor = "COD"

# def Get_Sensor_Configurations(sensor):
#         '''
#         Description:        Returns the specified device configurations.
#         Input Parameters:   Device information whose output is in LittleIndian format
#         Output Type:        list

#         '''
#         try:

#             sensor_config = "{}_Configurations".format(sensor)
#             with open("Z_Z_D1.json", 'r') as file:
#                 data = json.load(file)
#                 # print(data)

#             if sensor_config in data:
#                 sensor_configurations = data[sensor_config]
#                 print(sensor_configurations)
#                 return sensor_configurations
#             else:
#                 print("No variables found")
#         except Exception as e:
#             Data_Logs().Error_log(errorMessage(validation["MKC1"]))
#             print(errorMessage(validation["MKC1"]))
#             return errorMessage(validation["MKC1"])
            
        
            

# # Get_Sensor_Configurations(sensor)

def Configuration_Add(sensor, value):

    try:
        with open("Z_Z_D.json", 'r+') as file:
            file_data = json.load(file)
            print(file_data)
            if value not in file_data[sensor]:
                file_data[sensor].append(value)
                file.seek(0)
                json.dump(file_data, file, indent=4)
            else:
                return errorMessage(validation["MKC3"])
    except:
            return errorMessage(validation["MKC2"])

sensor="Energymeter"
data= {'Time': 15,'Energymeter': [171, 1], 'COD': [101, 9729,10], 'BOD': [101, 9729, 10], 'Temperature': [101, 10], 'TSS': [101, 4608, 4], 'Ph': [110, 9729, 5], 'TDS': [120, 9729, 4]}
    
def Configuration_Add_Sensor_Details(data, sensor):
        '''
        Description:        Add Sensor details to Sensor_Configuration_File
        Input Parameters:   Sensor and Corresponding details of the sensor
        Output Type:        None        
        '''
        try:
            sensor_config = "{}_Configurations".format(sensor)
            print(sensor_config)
            print("@@@@@@@@",data[sensor])
            length_key = len(data[sensor])
            # print(type(data[sensor]))
            if length_key==3:
                New_Configuration = {}
                New_Configuration["Device_ID"] = data[sensor][0]
                New_Configuration["Start_Address"] = data[sensor][1]
                New_Configuration["Register_Counts"] = data[sensor][2]
                print(New_Configuration)
            return Configuration_Add(
                sensor_config, New_Configuration)
            
                
        except:
            Data_Logs().Error_log(errorMessage(validation["MKC7"],sensor))
            print(errorMessage(validation["MKC7"]))
            return errorMessage(validation["MKC7"])

Configuration_Add_Sensor_Details(data, sensor)


from General_Configurations import Iot_Connection_String, Network_Connection_Error, Ethernet_Network_Error, Variable_Header, Command_Type

from azure.iot.device import IoTHubDeviceClient, Message

import ast


# def Iothub_Client_Init():
#         '''
#         Description:        Instantiate the client from a IoTHub device or module connection string.
#         Input Parameters:   None
#         Output Type:        azure.iot.device
#         '''
#         iothub_client = IoTHubDeviceClient.create_from_connection_string(
#             Iot_Connection_String)
#         return iothub_client

# def Iothub_Client_Telemetry_Sample_Run(reading):
#         '''
#         Description:        To send the relevant information to Iothub. 
#         Input Parameters:   Message needs to sent to Iothub.
#         Output Type:        None

#         '''
#         try:
#             iothub_client = Iothub_Client_Init()
#             message = Message(str(reading))
#             print("Sending message: {}".format(message))
#             iothub_client.send_message(message)
#             print("Message successfully sent")

#         except Exception as e:
#             print("Network_Connection_Error")

# def Azure_Read():
#         '''
#         Description:        The input message is convereted to the data received from the sensors.
#         Input Parameters:   None
#         Output type:        Dictionary if message is received appropriately else a string.
#         '''
#         try:
#             azure_input = str(input("Enter the message: "))
#             Command_Type = azure_input[0]
#             Control_Flag = azure_input[1]
#             Total_Length = int(azure_input[2:10], 16)
#             Variable_Length = int(azure_input[10:18], 16)
#             Topic_Name = azure_input[18: 18 + Variable_Length]
#             Message_Length = int(
#                 azure_input[18 + Variable_Length: 26 + Variable_Length], 16)
#             Message_Content = azure_input[26 + Variable_Length:]

#             if Total_Length == (Variable_Length + Message_Length + 16):
#                 receive_data = ast.literal_eval(Message_Content)
#                 Data_Logs().Receive_Data_Logs(receive_data)
#                 Iothub_Client_Telemetry_Sample_Run(receive_data)
#                 return receive_data
#             else:
#                 print("The message is not being received appropriately.")
#         except: 
#             print(errorMessage(validation["MKC5"]))
#             return errorMessage(validation["MKC5"])
# Azure_Read()




# def Clear_Configuration(data):
#         '''
#         Description:        Clear data from Sensor_Configuration_File
#         Input Parameters:   data retrieved from Azure
#         Output Type:        None
#         '''
#         azure_data = ast.literal_eval(data)
#         if "RESET" in azure_data:
#             with open("Z_Z_D1.json", 'r') as file:
#                 json_data = json.load(file)
#                 json_data["Energymeter_Configurations"].clear()
#                 json_data["COD_Configurations"].clear()
#                 json_data["BOD_Configurations"].clear()
#                 json_data["Temperature_Configurations"].clear()
#                 json_data["TSS_Configurations"].clear()
#                 json_data["Ph_Configurations"].clear()
#                 json_data["TDS_Configurations"].clear()
#             with open("Z_Z_D1.json", 'w') as file:
# #                 json.dump(json_data, file)
data= "{'Time': 15,'Energymeter': [171,1], 'COD': [101, 9729, 10], 'BOD': [101, 9729, 10], 'Temperature': [101, 9729, 10], 'TSS': [101, 4608, 4], 'Ph': [110, 9729, 5], 'TDS': [120, 9729, 4]}"
# a = "RESET"


# def Adding_Sensor_Configuration(data):
#         '''
#         Description:        Add Sensor details to Sensor_Configuration_File from the input data
#         Input Parameters:   data retrieved from Azure
#         Output Type:        None
#         '''
#         try:
#             azure_data = ast.literal_eval(data)
#             # print("hjhjhjhjhj",azure_data)
#             if "Energymeter" in azure_data:
#                 Configuration_Add_Sensor_Details(azure_data, "Energymeter")
#             if "COD" in azure_data:
#                 Configuration_Add_Sensor_Details(azure_data, "COD")
#             if "BOD" in azure_data:
#                 Configuration_Add_Sensor_Details(azure_data, "BOD")
#             if "Temperature" in azure_data:
#                 Configuration_Add_Sensor_Details(azure_data, "Temperature")
#             if "TSS" in azure_data:
#                 Configuration_Add_Sensor_Details(azure_data, "TSS")
#             if "Ph" in azure_data:
#                 Configuration_Add_Sensor_Details(azure_data, "TSS")
#             if "TDS" in azure_data:
#                 Configuration_Add_Sensor_Details(azure_data, "TSS")
#         except:
#             Data_Logs().Error_log(errorMessage(validation["MKC6"]))
#             print(errorMessage(validation["MKC6"]))
#             return errorMessage(validation["MKC6"])



# Adding_Sensor_Configuration(data)



# def Clear_Configuration(data):
#         '''
#         Description:        Clear data from Sensor_Configuration_File
#         Input Parameters:   data retrieved from Azure
#         Output Type:        None
#         '''
#         try:
#             #azure_data = ast.literal_eval(data)
#             if "RESET" in data:
#                 with open("Z_Z_D1.json", 'r') as file:
#                     json_data = json.load(file)
#                     print("DATA",json_data)
#                     json_data["Energymeter_Configurations"].clear()
#                     json_data["COD_Configurations"].clear()
#                     json_data["BOD_Configurations"].clear()
#                     json_data["Temperature_Configurations"].clear()
#                     json_data["TSS_Configurations"].clear()
#                     json_data["Ph_Configurations"].clear()
#                     json_data["TDS_Configurations"].clear()
#                 with open("Z_Z_D1.json", 'w') as file:
#                     json.dump(json_data, file)
#         except Exception as e:
#             Data_Logs().Error_log(errorMessage(validation["MKC2"]))
#             return errorMessage(validation["MKC2"])
# Clear_Configuration(a)


# def Configuration_Rewrite(variable, value):
#         '''
#         Description:        read the Sensor_Configuration_File and overwrite the file with input time
#         Input Parameters:   "Frequency_Time" and input time
#         Output Type:        None
#         '''
#         try:

#             with open("Z_Z_D1.json", 'r') as file:
#                 json_data = json.load(file)
#                 if variable in json_data:
#                     json_data[variable] = value
#                 else:
#                     return errorMessage(validation["MKC1"])
#             with open("Z_Z_D1.json", 'w') as file:
#                 json.dump(json_data, file)
#         except:
#             Data_Logs().Error_log(errorMessage(validation["MKC2"]))
#             return errorMessage(validation["MKC2"])

# def Setting_Frequency_Time(data):
#         '''
#         Description:        overwriting the time in Sensor_Configuration_File with that we get in the input data    
#         Input Parameters:   data retrieved from Azure
#         Output Type:        None
#         '''
#         try:
#             azure_data = ast.literal_eval(data)
#             if "Time" in azure_data:
#                 New_Frequency_Time = str(float(azure_data["Time"]))
#                 Configuration_Rewrite("Frequency_Time", New_Frequency_Time)
#                 print("New_Frequency_Time",New_Frequency_Time)
#                 return New_Frequency_Time
#             else:
#                 print("No change in time")
#         except:
#             Data_Logs().Error_log(errorMessage(validation["MKC6"]))
#             return errorMessage(validation["MKC6"])

# data ={'Time': 15,'Energymeter': [171, 1, 46], 'COD': [101, 9729, 10], 'BOD': [101, 9729, 10], 'Temperature': [101, 9729, 10], 'TSS': [101, 4608, 4], 'Ph': [110, 9729, 5], 'TDS': [120, 9729, 4]}
# Setting_Frequency_Time(data)
# from pymodbus.client.sync import ModbusTcpClient
# from General_Configurations import Gateway_Ip_Address, Gateway_Port, Sensor_Configuration_File
# from General_Configurations import Modbus_Error_Message, Modbus_Error, Modbus_Slave_Id_Error_Message, Modbus_Slave_Id_Error, Power_Error_Message, Power_Error

# def Gateway_Connect():
#     gateway_client = ModbusTcpClient(Gateway_Ip_Address, Gateway_Port)
#     gateway_client.connect()
#     return gateway_client

# def Get_Sensor_Reading(sensor):
#     sensor_result = []
#     Connection_Checking_Count = 0
#     sensor_config = "{}_Configurations".format(sensor)
#     with open("Z_Z_D.json", 'r') as file:
#         data = json.load(file)
#     if sensor_config in data:
#         sensor_configurations = data[sensor_config]
#         for i in range(len(sensor_configurations)):
#             sensor_details = {"{}_Device_Id".format(
#                 sensor): sensor_configurations[i]["Device_ID"]}
#             while True:
#                 Sensor_Reading = Gateway_Connect().read_holding_registers(
#                     count=sensor_configurations[i]["Register_Counts"], address=sensor_configurations[i]["Start_Address"], unit=sensor_configurations[i]["Device_ID"])
#                 Sensor_Reading_check = str(Sensor_Reading)

#                 if Sensor_Reading_check == Modbus_Error_Message:
#                     Connection_Checking_Count = Connection_Checking_Count+1
#                     if Connection_Checking_Count == 10:
#                         sensor_result.append(sensor_details | Modbus_Error)
#                         break

#                 elif Sensor_Reading_check == Modbus_Slave_Id_Error_Message:
#                     sensor_result.append(
#                         sensor_details | Modbus_Slave_Id_Error)
#                     break

#                 elif Sensor_Reading_check == Power_Error_Message:
#                     sensor_result.append(sensor_details | Power_Error)
#                     break

#                 else:
#                     sensor_result.append(Sensor_Reading.registers)
#                     break
#         print(sensor_result)
#         return sensor_result


# sensor = "COD"
# Get_Sensor_Reading(sensor)

#azure-iot-common
Internal library of components shared between the Azure IoT device and service SDKs.

[![npm version](https://badge.fury.io/js/azure-iot-common.svg)](https://badge.fury.io/js/azure-iot-common)

NOTE: You generally don't want to reference this package directly. The components you need should be exposed by packages in the device (`azure-iot-device*`) or service (`azure-iothub`) SDKs.
Security module used to provide TPM authentication capabilities to the Azure IoT Hub device client and Azure IoT Hub Provisioning Service device client.

[![npm version](https://badge.fury.io/js/azure-iot-security-tpm.svg)](https://badge.fury.io/js/azure-iot-security-tpm)

*This package is currently in development and has not been released yet*



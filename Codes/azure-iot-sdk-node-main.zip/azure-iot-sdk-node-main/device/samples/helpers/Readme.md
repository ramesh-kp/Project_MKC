# Helpers

## Device Twin Service

This project is used to mimic a real world scenario of a backend service sending device twin desired properties update to a device. It works along side the `simple_sample_device_twin` samples.

[Learn more](./device-twin-service/Readme.md)
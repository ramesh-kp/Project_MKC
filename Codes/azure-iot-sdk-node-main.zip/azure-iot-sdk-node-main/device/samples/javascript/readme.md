# Javascript Samples for the Azure IoT device SDK for Node.js

This folder contains simple samples showing how to use the various features of the Microsoft Azure IoT Hub service from a device written using JavaScript.

For instructions on running the JavaScript samples, see the [readme.md](../../samples) in the root samples folder.
